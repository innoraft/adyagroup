﻿<?php
// $Id: user-picture.tpl.php,v 1.1.2.2 2010/10/20 13:49:43 shannonlucas Exp $
/**
 * @file
 * Wraps the user picture in a div with a CSS class.
 */
?>
<div class="user-picture">
<?php print $picture; ?>
</div>