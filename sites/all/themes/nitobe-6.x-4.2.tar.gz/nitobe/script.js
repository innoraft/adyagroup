// $Id: script.js,v 1.1.8.1 2009/06/19 02:36:38 shannonlucas Exp $

/**
 * @file script.js
 * General JavaScript functions for the theme. A default file is required to
 * get Drupal to automatically load jQuery.
 */
