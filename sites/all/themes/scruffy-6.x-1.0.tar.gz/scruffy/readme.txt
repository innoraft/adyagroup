This is a free WordPress by FRESH01.co.za

For a full list of default theme features and license, please visit:

http://fresh01.co.za/2008/07/14/default-free-theme-features/

###Installation:

1. Extract the "themename.zip" folder.
2. Transfer the extracted "themename" folder to wp-content/themes
3. Go to WordPress Admin -> Design -> Themes to activate the themes.


###FlickrRSS plugin setup:

1. Install and activate the FlickrRSS plugin (http://eightface.com/wordpress/flickrrss/)
2. Go to WordPress admin -> settings -> flickrRSS
3. Insert the following for HTML Wrapper:
    Before Image: <p class="flickrrss">
	After Image: </p>